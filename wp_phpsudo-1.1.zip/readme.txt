Date de développement : 2008 / maj 2023
Nicolas Lion : nlion49@gmail.com / https://www.nlion.fr
Compatible PHP 7-8

licensed under the Creative Commons - Attribution - Non-Commercial license.

Pluggin Word Press V1.10

L’application permet de générer des grilles de tout type, garantissant toujours une solution unique. L’application propose des grilles de divers formats, allant de 4×4 à 16×16, offrant la possibilité d’utiliser des lettres, des chiffres ou même un mélange des deux. L'application est codé en php, javascript et css.

The application generates grids of various types, always guaranteeing a unique solution. It offers grids in various formats, ranging from 4×4 to 16×16, allowing the use of letters, numbers, or even a mix of both. The application is coded in PHP, JavaScript, and CSS.