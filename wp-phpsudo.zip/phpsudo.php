<?php
/**
 * Plugin Name:       PhpSudo: Sudoku 
 * Plugin URI:        https://www.nlion.fr/script-php-javascript-sudoku/
 * Description:       Grilles de sudoku de tout type, garantissant toujours une solution unique. L’application propose des grilles de divers formats, allant de 4×4 à 16×16, offrant la possibilité d’utiliser des lettres, des chiffres ou même un mélange des deux. Pour afficher une grille sur vos pages / articles utiliser la balise : [PHPsudo] Prochaine version sudoku administrable. Il faut que je trouve du temps :) Merci de laisser mon lien vers mon site, j'ai besoin de pub :)
 * Version:           1.0.0
 * Author:            Nicolas Lion
 * Author URI:        https://www.nlion.fr
 */
// répertoire de travail
define( 'base_url_phpsudo', plugin_dir_path(__FILE__));
define( 'chemin_relatif_plugin', plugin_dir_url( __FILE__ ));


register_activation_hook( base_url_phpsudo, 'phpsudo_activation_hook' );

// Ajouter jQuery
function ajouter_jquery() {
    wp_enqueue_script('jquery');
}


// Fonction pour charger le script JavaScript du plugin
function charger_script_plugin() {
    // Inclure le fichier JavaScript du plugin
    wp_enqueue_script('PHPSudoJS', plugin_dir_url(__FILE__) . 'js/phpsudo.js.php', array('jquery'), '1.0', true);
}
add_action('wp_enqueue_scripts', 'charger_script_plugin');

// Fonction pour détecter et remplacer la balise [sudoku]
function afficher_sudoku( $content ) {
    

	// Ajouter le chargement du script à l'action wp_enqueue_scripts

	// Vérifier si le contenu contient la balise [sudoku]
    if ( strpos( $content, '[PHPsudo]' ) !== false ) {
        // Insérer le code ou le script de votre plugin

        
        
        $monsudoku='<div id="sudoku">
		
         <div id="grille_sudoku_wp"></div>
			<script type="text/javascript">
			 jQuery.noConflict();
			  // Fonction anonyme enveloppant votre code jQuery
			jQuery(function($) {
				// Maintenant, $ est associé à jQuery

				$(\'#grille_sudoku_wp\').PhpSudo({
					\'TailleCasePX\': \'35\',
					\'Dimension\': \'9*3\',
					\'AfficheSelectionGrilles\': true,
					\'AfficherLaGrille\': true,
					\'TailleTexte\': \'22\',
					\'GenererNouvelleGrille\': true
				});
			});
			
			</script>
			
        </div>';
       
		$content = str_replace( '[PHPsudo]', $monsudoku, $content );

        // Ajouter le contenu du sudoku à la fin du contenu de l'article ou de la page
        //$content .= $sudoku_content;
    }

    // Renvoyer le contenu modifié
    return $content;
}

// Ajouter le filtre pour exécuter la fonction afficher_sudoku sur le contenu des articles et des pages
add_filter( 'the_content', 'afficher_sudoku' );




?>