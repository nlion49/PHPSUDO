=== phpsudo-sudoku ===
Contributors: Nicolas Lion
Donate link: https://www.paypal.com/donate/?hosted_button_id=SM9N9F4JYC6LG
Tags: Sudoku, Casse tête
Requires at least: 4.7
Tested up to: 6.4.3
Stable tag: 4.3
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Je de sudoku / Sudoku game. The application generates grids of various types, always guaranteeing a unique solution. It offers grids in various formats, ranging from 4×4 to 16×16, allowing the use of letters, numbers. 

== Description ==

Sudoku game. The application allows generating grids of any type, always guaranteeing a unique solution. The application offers grids in various formats, ranging from 4×4 to 16×16, providing the possibility to use letters, numbers, or even a mix of both.
3 levels of difficulty. The application integrates real-time correction and includes a timer to allow you to try to beat your best score. For solo play. No recordings.


Jeu de Sudoku. Cette application permet de créer des grilles de toutes sortes, garantissant toujours une solution unique. Elle propose des grilles de différents formats, allant de 4×4 à 16×16, et offre la possibilité d'utiliser des lettres, des chiffres ou même un mélange des deux.
Elle propose également 3 niveaux de difficulté, intègre une correction en temps réel et inclut un chronomètre pour vous permettre d'essayer de battre votre meilleur score. Destinée à être jouée en solo, elle ne propose pas de fonction d'enregistrement.


== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

= What about foo bar? =

Answer to foo bar dilemma.

== Screenshots ==

1. https://www.nlion.fr/wp-content/plugins/phpsudo/imgs/sudoku-grille9.jpg
2. https://www.nlion.fr/wp-content/plugins/phpsudo/imgs/sudoku-grille16.jpg

== Changelog ==

= 1.1 =
* Updating the client interface and implementing an administration panel to customize the grid display on a WordPress website.

Mise à jour de l'interface client et création d'un panneau d'administration pour personnaliser l'affichage de la grille sur un site WordPress.

= 1.0 =
* First version
