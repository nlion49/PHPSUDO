<?php
/**
 * Plugin Name:       PhpSudo: Sudoku 
 * Plugin URI:        https://www.nlion.fr/script-php-javascript-sudoku/
 * Description:       Grilles de sudoku de tout type, garantissant toujours une solution unique. L’application propose des grilles de divers formats, allant de 4×4 à 16×16, offrant la possibilité d’utiliser des lettres, des chiffres ou même un mélange des deux. Pour afficher une grille sur vos pages / articles utiliser la balise : [PHPsudo] ou utiliser le générateur de shortcode dans l'admin. Merci de laisser mon lien vers mon site, j'ai besoin de pub :)
 * Version:           1.1.1
 * Author:            Nicolas Lion
 * Author URI:        https://www.nlion.fr
 */
 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 
 
// répertoire de travail
define( 'base_url_phpsudo', plugin_dir_path(__FILE__));
define( 'chemin_relatif_plugin', plugin_dir_url( __FILE__ ));


register_activation_hook( base_url_phpsudo, 'phpsudo_activation_hook' );

// Ajouter jQuery
function ajouter_jquery() {
    wp_enqueue_script('jquery');
}


// Fonction pour charger le script JavaScript du plugin
function charger_script_plugin() {
    // Inclure le fichier JavaScript du plugin
    wp_enqueue_script('PHPSudoJS', plugin_dir_url(__FILE__) . 'js/phpsudo.js.php', array('jquery'), '1.0', true);
}
add_action('wp_enqueue_scripts', 'charger_script_plugin');


function afficher_sudoku( $content ) {
    // Ajouter le chargement du script à l'action wp_enqueue_scripts

    // Vérifier si le contenu contient la balise [sudoku]
    if ( strpos( $content, '[PHPsudo' ) !== false ) {
        // Extraire les valeurs du shortcode s'il y en a
        preg_match('/\[PHPsudo_TailleCasePX=(\d+)\|TailleTexte=(\d+)\|Dimension=(\d+\*\d+)\|DifficultyLevel=(\d+)\|AfficheSelectionGrilles=(true|false)\|AfficherLaGrille=(true|false)\|GenererNouvelleGrille=(true|false)\]/', $content, $matches);

        // Si des valeurs ont été trouvées dans le shortcode
        if (!empty($matches)) {
            // Assigner les valeurs extraites après validation
            $TailleCasePX = intval( $matches[1] ); // Convertir en entier
            $TailleTexte = intval( $matches[2] ); // Convertir en entier
            $Dimension = esc_attr( $matches[3] ); // Échapper les caractères spéciaux
            $DifficultyLevel = intval( $matches[4] ); // Convertir en entier
            $AfficheSelectionGrilles = $matches[5] === 'true' ? true : false; // Convertir en booléen
            $AfficherLaGrille = $matches[6] === 'true' ? true : false; // Convertir en booléen
            $GenererNouvelleGrille = $matches[7] === 'true' ? true : false; // Convertir en booléen

            // Générer le contenu HTML avec les valeurs extraites
            $monsudoku = '<div id="sudoku">';
            $monsudoku .= '<div id="grille_sudoku_wp"></div>';
            $monsudoku .= '<script type="text/javascript">';
            $monsudoku .= 'jQuery.noConflict();';
            $monsudoku .= 'jQuery(function($) {';
            $monsudoku .= '$(\'#grille_sudoku_wp\').PhpSudo({';
            $monsudoku .= '\'TailleCasePX\': \'' . $TailleCasePX . '\',';
            $monsudoku .= '\'Dimension\': \'' . $Dimension . '\',';
            $monsudoku .= '\'AfficheSelectionGrilles\': ' . ($AfficheSelectionGrilles ? 'true' : 'false') . ','; // Convertir en chaîne
            $monsudoku .= '\'AfficherLaGrille\': ' . ($AfficherLaGrille ? 'true' : 'false') . ','; // Convertir en chaîne
            $monsudoku .= '\'TailleTexte\': \'' . $TailleTexte . '\',';
			$monsudoku .= '\'Niveau\': \'' . $DifficultyLevel . '\',';
            $monsudoku .= '\'GenererNouvelleGrille\': ' . ($GenererNouvelleGrille ? 'true' : 'false'); // Convertir en chaîne
            $monsudoku .= '});';
            $monsudoku .= '});';
            $monsudoku .= '</script>';
            $monsudoku .= '</div>';

            // Remplacer le shortcode dans le contenu par le contenu généré
            $content = str_replace($matches[0], $monsudoku, $content);
        } else {
            // Si le shortcode ne contient pas de paramètres, afficher le sudoku par défaut
            $monsudoku = '<div id="sudoku">';
            $monsudoku .= '<div id="grille_sudoku_wp"></div>';
            $monsudoku .= '<script type="text/javascript">';
            $monsudoku .= 'jQuery.noConflict();';
            $monsudoku .= 'jQuery(function($) {';
            $monsudoku .= '$(\'#grille_sudoku_wp\').PhpSudo({';
            $monsudoku .= '\'TailleCasePX\': \'35\',';
            $monsudoku .= '\'Dimension\': \'9*3\',';
            $monsudoku .= '\'AfficheSelectionGrilles\': true,';
            $monsudoku .= '\'AfficherLaGrille\': true,';
            $monsudoku .= '\'TailleTexte\': \'22\',';
            $monsudoku .= '\'GenererNouvelleGrille\': true';
            $monsudoku .= '});';
            $monsudoku .= '});';
            $monsudoku .= '</script>';
            $monsudoku .= '</div>';

            // Remplacer le shortcode dans le contenu par le contenu généré
            $content = str_replace('[PHPsudo]', $monsudoku, $content);
        }
    }

    // Renvoyer le contenu modifié
    return $content;
}
// Ajouter le filtre pour exécuter la fonction afficher_sudoku sur le contenu des articles et des pages
add_filter( 'the_content', 'afficher_sudoku' );

// Fonction pour créer la page d'administration
function phpsudo_admin_page() {
    add_menu_page(
        'Sudoku',
        'Sudoku',
        'manage_options',
        'phpsudo-settings',
        'phpsudo_settings_page_content',
        'dashicons-grid-view'
    );
}
add_action('admin_menu', 'phpsudo_admin_page');


function phpsudo_settings_page_content() {
    ?>
<div class="wrap" style="font-size:16px;">
        
<div style="color:#333;">
<br />
Plugin Name:       PhpSudo 1.1<br />
Plugin URI:        <a href="https://www.nlion.fr/script-php-javascript-sudoku/">https://www.nlion.fr/script-php-javascript-sudoku/</a><br />
Author:            Nicolas Lion<br />
Author URI:        <a href="https://www.nlion.fr">https://www.nlion.fr</a><br />

</div> <br /><hr />
<h1>Comment afficher le Sudoku sur votre site Wordpress ?</h1>
Bienvenue dans l'interface d'administration du plugin Sudoku !<br />

Vous souhaitez afficher des grilles de Sudoku sur vos pages ou articles WordPress ? <br /><br />C'est simple avec ce plugin ! 
Le shortcode <span style="font-size:24px;fonct-weight:bold;">[PHPsudo]</span> vous permet d'afficher une grille classique de sudoku de niveau facile avec possibilité de 
choisir une autre grille avec options.<br />
<br />
Pour personaliser votre affichage, je vous propose le petit formulaire ci-dessous pour générer votre shortcode.

		
<form id="sudoku-generator-form" style="padding: 20px;">
    <div style="background-color: #f8f8f8; padding: 10px;">
        <label for="taille-case-px" style="display: inline-block; width: 200px;">Taille de la case (en pixels):</label>
        <input type="text" id="taille-case-px" name="taille-case-px" value="35" maxlength="2" style="width:35px;">
    </div>
    
    <div style="background-color: #ffffff; padding: 10px;">
        <label for="taille-texte" style="display: inline-block; width: 200px;">Taille du texte:</label>
        <input type="text" id="taille-texte" name="taille-texte" value="22" maxlength="2" style="width:35px;">
    </div>
    
    <div style="background-color: #f8f8f8; padding: 10px;">
        <label for="dimension" style="display: inline-block; width: 200px;">Dimension:</label>
        <select id="dimension" name="dimension" style="background-color: #ffffff;">
            <option value="4*2">4X4</option>
            <option value="6*3">6X6</option>
            <option value="8*4">8X8</option>
            <option value="9*3">9X9</option>
            <option value="10*5">10X10</option>
            <option value="12*3">12X12</option>
            <option value="14*7">14X14</option>
            <option value="16*4">16X16</option>
        </select>
    </div>

    <div style="background-color: #ffffff; padding: 10px;">
        <label for="difficulty-level" style="display: inline-block; width: 200px;">Niveau de difficulté:</label>
        <select id="difficulty-level" name="difficulty-level" style="background-color: #f8f8f8;">
            <option value="0">Facile</option>
            <option value="1">Moyen</option>
            <option value="2">Difficile</option>
        </select>
    </div>

    <div style="background-color: #f8f8f8; padding: 10px;">
        <input type="checkbox" id="affiche-selection-grilles" name="affiche-selection-grilles" style="background-color: #f8f8f8;">
        <label for="affiche-selection-grilles" style="display: inline-block; width: 200px;">Afficher la sélection des grilles</label>
    </div>

    <div id="grid-options" style="display:none; background-color: #ffffff; padding: 10px;">
        <input type="checkbox" id="afficher-la-grille" name="afficher-la-grille" style="background-color: #f8f8f8;" checked>
        <label for="afficher-la-grille" style="display: inline-block; width: 200px;">Afficher la grille par défaut</label>

        <br><br>

        <input type="checkbox" id="generer-nouvelle-grille" name="generer-nouvelle-grille" style="background-color: #f8f8f8;">
        <label for="generer-nouvelle-grille" style="display: inline-block; width: 200px;">Générer une nouvelle grille</label>
    </div>

    <button type="button" id="generate-shortcode-button" style="margin-left: 200px; margin-top: 20px;">Générer le Shortcode</button>
</form>
		<h3>Shortcode : </h3>
        <div id="generated-shortcode" style="min-height:15px;margin-top:20px;font-size:18px;fonct-weight:bold;padding:5px;background:#fff;border:1px solid #ccc;">[PHPSudo]</div>
		
		
		
<h3>Voici comment ça fonctionne :</h3>
Copiez-collez : Copiez simplement le shortcode généré ci-dessus et collez-le dans votre page ou article WordPress.<br /> 
C'est tout ! Votre grille de Sudoku apparaîtra là où vous l'avez insérée.
<br />
<br />N'oubliez pas que vous pouvez toujours revenir ici pour ajuster vos paramètres et générer un nouveau shortcode à tout moment.
<br />
<br />Facile, n'est-ce pas ? Amusez-vous bien à créer vos grilles de Sudoku personnalisées !<br /><br />

<a href="https://www.paypal.com/donate/?hosted_button_id=SM9N9F4JYC6LG" style="font-size:24px;">Vous voulez m'offrir un petit café ? :) Merci</a> 
</div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var afficheSelectionGrillesCheckbox = document.getElementById('affiche-selection-grilles');
            var gridOptionsDiv = document.getElementById('grid-options');
            var afficherLaGrilleCheckbox = document.getElementById('afficher-la-grille');
            var genererNouvelleGrilleCheckbox = document.getElementById('generer-nouvelle-grille');

            afficheSelectionGrillesCheckbox.addEventListener('change', function() {
                if (afficheSelectionGrillesCheckbox.checked) {
                    gridOptionsDiv.style.display = 'block';
                } else {
                    gridOptionsDiv.style.display = 'none';
                    afficherLaGrilleCheckbox.checked = true;
                    genererNouvelleGrilleCheckbox.checked = false;
                }
            });

            document.getElementById('generate-shortcode-button').addEventListener('click', function() {
                var tailleCasePX = document.getElementById('taille-case-px').value;
                var dimension = document.getElementById('dimension').value;
                var difficultyLevel = document.getElementById('difficulty-level').value;
                var afficheSelectionGrilles = document.getElementById('affiche-selection-grilles').checked;
                var afficherLaGrille = document.getElementById('afficher-la-grille').checked;
                var tailleTexte = document.getElementById('taille-texte').value;
                var genererNouvelleGrille = document.getElementById('generer-nouvelle-grille').checked;

                // Vérification de la saisie pour tailleCasePX et tailleTexte
                if (!(/^\d+$/.test(tailleCasePX))) {
                    alert("La taille de la case doit être un entier positif.");
                    return;
                }
                if (!(/^\d+$/.test(tailleTexte))) {
                    alert("La taille du texte doit être un entier positif.");
                    return;
                }

				
					
					
                var shortcode = '[PHPsudo_';
                shortcode += 'TailleCasePX=' + tailleCasePX + '|';
                shortcode += 'TailleTexte=' + tailleTexte + '|';
                shortcode += 'Dimension=' + dimension + '|';
                shortcode += 'DifficultyLevel=' + difficultyLevel + '|';
                shortcode += 'AfficheSelectionGrilles=' + afficheSelectionGrilles + '|';
                
                    shortcode += 'AfficherLaGrille=' + afficherLaGrille + '|';
                    shortcode += 'GenererNouvelleGrille=' + genererNouvelleGrille + '';
                
                shortcode += ']';

                document.getElementById('generated-shortcode').innerText = shortcode;
            });
        });
    </script>
    <?php
}