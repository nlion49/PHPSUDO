<?php
header("Content-Type: text/plain");
header("Cache-Control: no-cache, must-revalidate"); 
header("Access-Control-Allow-Origin: *");
/*
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
*/
//require_once '_inc.config.php';
require_once '_inc.class.template.php';
require_once '_inc.class.sudoku.php';

function display_sudoku_grid($html) {
    $allowed_tags = array(
        'div' => array(
            'id' => true,
            'class' => true,
            'style' => true,
        ),
        'form' => array(
            'style' => true,
            'class' => true,
            'onsubmit' => true,
        ),
        'select' => array(
            'name' => true,
            'id' => true,
            'style' => true,
        ),
        'option' => array(
            'value' => true,
        ),
        'input' => array(
            'type' => true,
            'name' => true,
            'id' => true,
            'value' => true,
            'class' => true,
            'readonly' => true,
            'onkeyup' => true,
            'style' => true,
            'autocomplete' => true,
        ),
        'a' => array(
            'href' => true,
            'onclick' => true,
            'title' => true,
            'target' => true,
            'style' => true,
        ),
        'img' => array(
            'height' => true,
            'src' => true,
            'border' => true,
        ),
        'span' => array(
            'id' => true,
            'style' => true,
        ),
        'input' => array(
            'type' => true,
            'name' => true,
            'id' => true,
            'onclick' => true,
        ),
        'textarea' => array(
            'name' => true,
            'id' => true,
            'onkeyup' => true,
        ),
    );

    echo wp_kses($html, $allowed_tags);
}


// Vérification des entrées GET et définition des valeurs par défaut
$niveau = isset($_GET['niveau']) ? (int)$_GET['niveau'] : 2;
$dimension = isset($_GET['dimension']) ? $_GET['dimension'] : '9*3';

$type_ = explode('*', $dimension);
$w = isset($type_[0]) ? (int)$type_[0] : 9;
$h = isset($type_[1]) ? (int)$type_[1] : 3;
unset($type_);

if (!is_int($w % $h)) {
    die('Erreur sur le type de grille !');
}

$sudo=new SuDoKu(true,$w,$h,$niveau);

if(!$sudo->TimeOut)
{
	//récup du template
// Chemin du fichier à lire
$filename = 'grille.tpl';

// Vérifiez si le fichier existe et s'il est accessible
if (file_exists($filename) && is_readable($filename)) {
    // Ouvrez le fichier en mode lecture
    $template = fopen($filename, "r");
    
    // Vérifiez si l'ouverture du fichier a réussi
    if ($template) {
        // Lisez le contenu du fichier
        $TemplateGrille = fread($template, filesize($filename));
        
        // Fermez le fichier
        fclose($template);
    } else {
        // Gestion de l'erreur si l'ouverture du fichier a échoué
        // Par exemple :
        die('Impossible d\'ouvrir le fichier');
    }
} else {
    // Gestion de l'erreur si le fichier n'existe pas ou n'est pas accessible
    // Par exemple :
    die('Le fichier spécifié n\'existe pas ou n\'est pas accessible');
}


// on remplace par des symboles
if (isset($_GET['type']) && $_GET['type'] == 'lettres') {
    $type = sanitize_text_field($_GET['type']); // Nettoyage du type
    if ($type === 'lettres') {
        $sudo->WithSymbol = 'symbole'; // Assurez-vous que le type est correct avant de l'utiliser
    } else {
        // Gestion de l'erreur si le type n'est pas valide
        // Vous pouvez afficher un message d'erreur ou effectuer une autre action appropriée
        // Par exemple :
        die('Type invalide spécifié');
    }
}
	if(isset($_GET['type']) && $_GET['type']=='mixte')
	$sudo->WithSymbol='Mixte';
	$Grille=$sudo->drawing($sudo->IncompleteGrille,$TemplateGrille);
	$Grille->assign('SolutionSudoku',base64_encode($sudo->lineariser_grilles($sudo->GrillePleine)),$TemplateGrille);
	$Grille->assign('GrilleSudoku',base64_encode($sudo->lineariser_grilles($sudo->IncompleteGrille)),$TemplateGrille);
	$Grille->assign('DimSudoku',$dimension,$TemplateGrille);
	$Grille->assign('NiveauSudoku',$niveau,$TemplateGrille);
	
	
	
	
	echo $Grille->PrintPage($TemplateGrille);

	// Chemin du fichier à lire
	$filename = 'solution.tpl';

	// Vérifiez si le fichier existe et s'il est accessible
	if (file_exists($filename) && is_readable($filename)) {
		// Ouvrez le fichier en mode lecture
		$template = fopen($filename, "r");
		
		// Vérifiez si l'ouverture du fichier a réussi
		if ($template) {
			// Lisez le contenu du fichier
			$TemplateSolution = fread($template, filesize($filename));
			
			// Fermez le fichier
			fclose($template);
		} else {
			// Gestion de l'erreur si l'ouverture du fichier a échoué
			// Par exemple :
			die('Impossible d\'ouvrir le fichier');
		}
	} else {
		// Gestion de l'erreur si le fichier n'existe pas ou n'est pas accessible
		// Par exemple :
		die('Le fichier spécifié n\'existe pas ou n\'est pas accessible');
	}
	
	$Grille2=$sudo->drawing($sudo->GrillePleine,$TemplateSolution);
	echo $Grille2->PrintPage($TemplateSolution);
}
else
{
	echo 'TIMEOUT';
}
?>
